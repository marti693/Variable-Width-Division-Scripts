import time
from Divider import *
from DivWrapper import *
from VerilogSynthesis import *
from VMH import *
from ModelSim import *
from Parser import *

range1 = list(range(8,65))
range2 = range(1,33)
range2 = list([x * 2 + 64 for x in range2])
range3 = range(1,33)
range3 = list([x * 4 + 128 for x in range3])
range4 = range(1,33)
range4 = list([x * 8 + 256 for x in range4])
range5 = range(1,33)
range5 = list([x * 16 + 512 for x in range5])
range6 = range(1,33)
range6 = list([x * 32 + 1024 for x in range6])
#        8:1:64  66:2:128 132:4:256 256:8:512  528:16:1024 1056:32:2048
widths = range1 + range2 + range3 +  range4 +    range5 +     range6
for width in widths:
    print("width is " + str(width))
    method = "goldschmidt"
    name = method + str(width)
    makeExample = 1

    # build divider
    buildDivider(width, method, makeExample)

    # build vmh file
    # randomnums = buildVMH(width)
    randomnums = buildVMH_SRT(width)  # ensure that the divisor is half the width of the dividend

    # build divider wrapper
    buildWrapper(width, method, randomnums)  # wrapper for Trireme
    buildWrapper_alternate(width, method)   # wrapper for divider synthesis

    # run verilog synthesis
    dividerSynthesis()

    # run simulation
    TriremeSynthesis()
    simulate()

    # parse results
    parseResults(name)
