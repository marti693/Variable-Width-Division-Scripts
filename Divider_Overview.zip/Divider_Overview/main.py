import time
from Divider import *
from DivWrapper import *
from VerilogSynthesis import *
from VMH import *
from ModelSim import *
from Parser import *

width = 20
method = "test"
name = method + str(width)

#build divider
buildDivider(width, method)
edit_Testbench(width)

#build divider wrapper
buildWrapper(width, method)

#run verilog synthesis

dividerSynthesis()


#build vmh file
randomnums = buildVMH(width)

#run simulation
TriremeSynthesis()
simulate()

#parse results
#parseTriremeSynthesis(name)
#parseSynthesis(name)
parseResults(name, randomnums)
